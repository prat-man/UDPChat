package com.pramanda.udpchat.client;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.pramanda.udpchat.common.MessageType;
import com.pramanda.udpchat.notification.Notification;

public class ClientMain {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));

	public static void start(String hostname, int port, String name) {
		
		// load system default theme
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		
		// create frame
		JFrame frame = new JFrame("Ping.ME | " + name);
		
		// get frame container
		Container container = frame.getContentPane();
		
		// create wrapper panel
		JPanel panel = new JPanel(new BorderLayout(5, 5)) {
			private static final long serialVersionUID = 1102960360328342453L;

			@Override
			public Insets getInsets() {
				return new Insets(5, 5, 5, 5);
			}
		};
		
		// create text pane for displaying messages
		JTextPane textPane = new JTextPane();
		
		textPane.setPreferredSize(new Dimension(350, 300));
		
		textPane.setEditable(false);
		
		JScrollPane scrollPane = new JScrollPane(textPane);
		
		JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
		
		panel.add(scrollPane, BorderLayout.CENTER);
		
		// create client
		Client client = new Client(hostname, port, name, frame, textPane, verticalScrollBar);
		
		// create text field for sending messages
		JTextField textField = new JTextField();
		
		// listen to text field for ENTER key and send message
		textField.addActionListener((event) -> {
			if (!textField.getText().trim().equals("")) {
				client.sendData(textField.getText(), MessageType.TEXT);
			}
			textField.setText("");
		});
		
		panel.add(textField, BorderLayout.SOUTH);
		
		// add panel to container
		container.add(panel, BorderLayout.CENTER);
		
		// use custom action on clicking on the close button
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		frame.addWindowListener(new WindowAdapter() {

			// remove tray icon if window is activated
			@Override
			public void windowActivated(WindowEvent e) {
				Notification.removeTrayIcon();
			}
			
			// remove tray icon if window is deiconified
			@Override
			public void windowDeiconified(WindowEvent e) {
				Notification.removeTrayIcon();
			}
			
			// custom action when close button is clicked
		    @Override
		    public void windowClosing(WindowEvent windowEvent) {
		    	
		        if (JOptionPane.showConfirmDialog(frame, 
		            "Are you sure you want to disconnect?", "Ping.ME", 
		            JOptionPane.YES_NO_OPTION,
		            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
		        	
		        	client.sendData("disconnect", MessageType.INSTRUCTION);
		        	
		        	try {
						client.join();
					} catch (InterruptedException e) {
						System.err.println("[FATAL] Client interrupted");
					}
		        	
		        	System.exit(0);
		        	
		        }
		        
		    }
		    
		});
		
		// use most suitable size
		frame.pack();
		
		// make the frame visible
		frame.setVisible(true);
		
		// start the client
		client.start();
		
	}

}
