package com.pramanda.udpchat.server;

public class ServerMain {

	public static void start(int port) {
		
		Server server = new Server(port);
		
		server.start();
		
	}
	
}
