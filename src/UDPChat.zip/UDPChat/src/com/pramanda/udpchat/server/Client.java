package com.pramanda.udpchat.server;

import java.awt.Color;
import java.util.Random;

public class Client {

	private String hostname;
	private int port;
	private String name;
	private Color color;
	
	public static float MIN_SATURATION = 0.6f;
	public static float MAX_SATURATION = 0.8f;
	
	public static float MIN_BRIGHTNESS = 0.5f;
	public static float MAX_BRIGHTNESS = 0.7f;
	
	public Client(String hostname, int port) {
		this(hostname, port, null);
	}
	
	public Client(String hostname, int port, String name) {
		this.hostname = hostname;
		this.port = port;
		this.name = name;
		
		Random random = new Random();

		float h = random.nextFloat();
	    float s = MIN_SATURATION + (random.nextFloat() * (MAX_SATURATION - MIN_SATURATION));
	    float b = MIN_BRIGHTNESS + (random.nextFloat() * (MAX_BRIGHTNESS - MIN_BRIGHTNESS));
	    this.color = Color.getHSBColor(h, s, b);
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Color getColor() {
		return color;
	}

	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (!Client.class.isAssignableFrom(obj.getClass())) {
            return false;
        }

        Client other = (Client) obj;
        if (((this.hostname == null && other.hostname == null) || (this.hostname.equals(other.hostname))) && (this.port == other.port)) {
            return true;
        }

        return false;
    }
	
}
