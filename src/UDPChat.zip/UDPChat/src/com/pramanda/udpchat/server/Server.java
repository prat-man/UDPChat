package com.pramanda.udpchat.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.pramanda.udpchat.common.MessageType;

public class Server extends Thread {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));
	
	private int port;
	
	private DatagramSocket socket;
	
	private List<Client> clientList;
	
	private boolean kill = false;
	
	public Server(int port) {
		this.port = port;
		this.clientList = new ArrayList<Client>();
	}
	
	public void run() {
		
		try {
			socket = new DatagramSocket(port);
			
			socket.setSoTimeout(5000);
			
			byte[] buf = new byte[1024];
			
			DatagramPacket packet = new DatagramPacket(buf, 1024);
			
			System.out.println("[INFO] Server is starting.");
			
			Thread reader = new Thread(() -> {
			    while (!kill) {
			    	try {
			    		// try to receive a packet
					    socket.receive(packet);
					    
					    // get data from packet
					    String data = new String(packet.getData(), 0, packet.getLength()).trim();
					    
					    Client client = new Client(packet.getAddress().getHostAddress(), packet.getPort());
					    
					    MessageType messageType = null;
					    
					    if (data.toUpperCase().startsWith(MessageType.INSTRUCTION.name())) {
					    	messageType = MessageType.INSTRUCTION;
					    	data = data.substring(MessageType.INSTRUCTION.name().length()).trim();
					    } else if (data.toUpperCase().startsWith(MessageType.TEXT.name())) {
					    	messageType = MessageType.TEXT;
					    	data = data.substring(MessageType.TEXT.name().length()).trim();
					    }
					    
					    if (!clientList.contains(client)) {
					    	System.err.println("[" + packet.getAddress().getHostAddress() + ":" + packet.getPort() + "]");
						    System.err.println(data);
						    System.err.println();
						    
					    	if (messageType == MessageType.INSTRUCTION && data.toLowerCase().startsWith("connect ")) {
					    		String name = data.substring("connect ".length()).trim();
					    		
					    		if (name.equalsIgnoreCase("server")) {
					    			System.err.println("[ERROR] Invalid name. Name \"" + name + "\" not allowed.");
					    		}
					    		else {
						    		client.setName(name);
						    		clientList.add(client);
						    		
						    		broadcast(name + " has joined the conversation.");
					    		}
					    	}
					    	else {
					    		System.err.println("[ERROR] Use \"connect <name>\" to connect to the server.");
					    		reply("<ERROR> Use \"connect <name>\" to connect to the server.", client);
					    	}
					    }
					    else {
							client = clientList.get(clientList.indexOf(client));
							
							System.out.println("[" + packet.getAddress().getHostAddress() + ":" + packet.getPort() + "] " + client.getName());
						    System.out.println(data);
						    System.out.println();
					    	
					    	if (messageType == MessageType.INSTRUCTION && data.equalsIgnoreCase("disconnect")) {
						    	broadcast(client.getName() + " has left the conversation.");
						    	clientList.remove(clientList.indexOf(client));
					    	}
					    	else if (messageType == MessageType.TEXT) {
					    		broadcast(data, client);
					    	}
					    	else {
					    		System.err.println("[WARN] Message type not specified. Message silently dropped.");
					    	}
					    }
					    
					} catch (SocketTimeoutException e1) {
						// TIMEOUT
						// DO NOTHING
					} catch (IOException e) {
						System.err.println("[ERROR] Error while reading data!");
					}
			    }
			});
			
			reader.start();
			
			
			System.out.println("[INFO] Server is ready.");
			
		    
			// broadcast server input to clients
			while (!kill) {
				String sendData = IN.readLine();
				
				if (sendData.equalsIgnoreCase("shutdown")) {
					System.err.println("\n[INFO] Server is shutting down!");
					kill();
				}
				
				broadcast(sendData);
			}
			
			try {
				reader.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		catch (IOException e) {
			System.err.println("[FATAL] Could not open server socket!");
		}
		finally {
		    if (socket!= null) socket.close();
		}
	}
	
	public void broadcast(String data) {
		this.broadcast(data, null);
	}
	
	public void broadcast(String data, Client from) {
		
		data = (from != null) ? "[" + from.getName() + "] " + data : "[SERVER] " + data;
		
		if (!data.endsWith("\n")) data += "\n";
		
		byte[] dataBuf = data.getBytes();
		
		for (Client client : clientList) {
			if (client.equals(from)) continue;
			
			InetAddress IPAddress = null;
			try {
				IPAddress = InetAddress.getByName(client.getHostname());
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
			
			DatagramPacket packet = new DatagramPacket(dataBuf, dataBuf.length, IPAddress, client.getPort());
			
			try {
				socket.send(packet);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void reply(String data, Client to) {
		
		data = "[SERVER] " + data;

		if (!data.endsWith("\n")) data += "\n";
		
		byte[] dataBuf = data.getBytes();
		
		InetAddress IPAddress = null;
		try {
			IPAddress = InetAddress.getByName(to.getHostname());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		DatagramPacket packet = new DatagramPacket(dataBuf, dataBuf.length, IPAddress, to.getPort());
		
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void kill() {
		this.kill = true;
	}

	public int getPort() {
		return port;
	}
	
}
