package com.pramanda.udpchat.common;

public enum MessageType {

	INSTRUCTION, TEXT
	
}
