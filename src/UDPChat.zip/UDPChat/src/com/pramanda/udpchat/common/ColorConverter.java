package com.pramanda.udpchat.common;

import java.awt.Color;

public class ColorConverter {

	public static String colorToString(Color color) {
		if (color == null) return null;
		
		return String.format("%03d", color.getRed()) +		// red
				String.format("%03d", color.getGreen()) +	// green
				String.format("%03d", color.getBlue());		// blue
	}
	
	public static Color stringToColor(String str) {
		if (str == null || str.length() != 9) return null;
		
		try {
			int red = Integer.parseInt(str.substring(0, 3));
			int green = Integer.parseInt(str.substring(3, 6));
			int blue = Integer.parseInt(str.substring(6, 9));
			
			return new Color(red, green, blue);
		}
		catch (NumberFormatException e) {
			return null;
		}
	}
	
}
