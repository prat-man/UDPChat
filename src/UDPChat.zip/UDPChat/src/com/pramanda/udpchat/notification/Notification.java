package com.pramanda.udpchat.notification;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;

public class Notification {
	
	private static TrayIcon trayIcon;

    public static void display(JFrame frame, String message) {
    	
    	if (trayIcon == null && SystemTray.isSupported()) {
    		
	        // obtain only one instance of the SystemTray object
	        SystemTray tray = SystemTray.getSystemTray();
	
	        // get image file
	        Image image = Toolkit.getDefaultToolkit().createImage(TrayIcon.class.getResource("/img/icon.png"));
	
	        // create the tray icon
	        trayIcon = new TrayIcon(image, "Ping.ME");
	        
	        // let the system resize the image if needed
	        trayIcon.setImageAutoSize(true);
	        
	        // set tooltip text for the tray icon
	        trayIcon.setToolTip("Ping.ME");
	        
	        // add mouse listener
	        trayIcon.addMouseListener(new MouseAdapter() {
	        	
	        	public void mouseClicked(MouseEvent event) {
	        		// deiconify frame, bring to front, and repaint
	        		frame.setState(JFrame.NORMAL);
	        		frame.toFront();
	                frame.repaint();
	        	}
	        	
	        });
	        
	        try {
	        	// add the tray icon to the system tray
				tray.add(trayIcon);
		        
			} catch (AWTException e) {
				System.err.println("[WARN] Failed to display notification.");
			}
	        
    	}

    	// display the message
		trayIcon.displayMessage("Ping.ME", message, MessageType.INFO);
		
    }
    
    public static void removeTrayIcon() {
    	
    	if (trayIcon != null) {
	    	// obtain only one instance of the SystemTray object
	        SystemTray tray = SystemTray.getSystemTray();
	    	
	    	// remove the tray icon from the system tray
	        tray.remove(trayIcon);
	        
	        // make trayIcon as null
	        trayIcon = null;
    	}
        
    }
    
}
