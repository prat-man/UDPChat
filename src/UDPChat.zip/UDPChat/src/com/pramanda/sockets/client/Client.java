package com.pramanda.sockets.client;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import com.pramanda.sockets.notification.Notification;

public class Client extends Thread {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));
	
	private DatagramSocket socket;
	
	private String hostname;
	
	private int port;
	
	private String name;
	
	private InetAddress IPAddress;
	
	private JFrame frame;
	private JTextPane textPane;
	
	private boolean kill;
	
	public Client(String hostname, int port, String name, JFrame frame, JTextPane textPane) {
		this.hostname = hostname;
		this.port = port;
		this.name = name;
		this.frame = frame;
		this.textPane = textPane;
	}
	
	public void run() {
		
		try {
			
			socket = new DatagramSocket();
			
			socket.setSoTimeout(5000);
			
			System.err.println("[INFO] Client is starting.");
			
			try {
				IPAddress = InetAddress.getByName(hostname);
			} catch (UnknownHostException e1) {
				System.err.println("[FATAL] Invalid host name.");
				System.exit(0);
			}
			
			this.connect();
			
			byte[] buf = new byte[1024];
			
			DatagramPacket receivedPacket = new DatagramPacket(buf, 1024);
			
		    while (!kill) {
		    	
		    	try {
		    		// try to receive a packet
				    socket.receive(receivedPacket);
				    
				    // get data from packet
				    String receivedData = new String(receivedPacket.getData(), 0, receivedPacket.getLength()).trim();
				    
				    if (receivedData.equalsIgnoreCase("[SERVER] shutdown")) {
				    	System.err.println("[FATAL] Server is shutting down!");
				    	receivedData += "\n[FATAL] Server is shutting down!";
				    	kill();
				    }
				    
				    StyledDocument doc = textPane.getStyledDocument();

			        Style style = textPane.addStyle("", null);
			        
			        if (receivedData.startsWith("[SERVER] ")) {
			        	StyleConstants.setForeground(style, Color.red);
			        }
			        else {
			        	StyleConstants.setForeground(style, Color.blue);
			        }

			        try {
			        	doc.insertString(doc.getLength(), receivedData + "\n", style);
			        	
			        	if (!frame.hasFocus() && !kill) {
			        		Notification.display(frame, "You may have new messages");
			        	}
			        }
			        catch (BadLocationException e) {
			        	System.err.println("[ERROR] Bad location to insert text.");
			        }
				    
		    	} catch (SocketTimeoutException e1) {
					// TIMEOUT
					// DO NOTHING
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.println("[ERROR] Client failed to receive data from server.");
				}
		    }
		    
		    System.err.println("[INFO] Client has disconnected.");
		    
		}
		catch (SocketException e) {
			System.err.println("[FATAL] Client failed to open socket.");
			System.exit(0);
		}
		finally {
			if (socket != null) socket.close();
		}
		
	}
	
	public void connect() {
		
		String data = "connect " + name;
		
		byte[] dataBuf = data.getBytes();
		
		DatagramPacket packet = new DatagramPacket(dataBuf, dataBuf.length, IPAddress, port);
		
		try {
			socket.send(packet);
			
			System.err.println("[INFO] Client is ready.");
		} catch (IOException e) {
			System.err.println("[FATAL] Client failed to connect to server.");
			System.exit(0);
		}
		
	}
	
	public void sendData(String data) {
		
		if (data == null) return;
		
		if (data.equalsIgnoreCase("disconnect")) {
			System.err.println("[INFO] Client is disconnecting.");
			kill();
		}
		
		byte[] sendBuf = data.getBytes();
		
		DatagramPacket sendPacket = new DatagramPacket(sendBuf, sendBuf.length, IPAddress, port);
		
		try {
			
			socket.send(sendPacket);
			
			StyledDocument doc = textPane.getStyledDocument();

	        Style style = textPane.addStyle("", null);
	        
	        StyleConstants.setForeground(style, Color.black);

	        try {
	        	doc.insertString(doc.getLength(), "[YOU] " + data + "\n", style);
	        }
	        catch (BadLocationException e) {
	        	System.err.println("[ERROR] Bad location to insert text.");
	        }
	        
		} catch (IOException e) {
			System.err.println("[ERROR] Client failed to send data to server.");
		}
		
	}
	
	public void kill() {
		this.kill = true;
	}
	
}
