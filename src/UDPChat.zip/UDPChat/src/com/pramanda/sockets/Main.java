package com.pramanda.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.pramanda.sockets.client.ClientMain;
import com.pramanda.sockets.server.ServerMain;

public class Main {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) {
		
		if (args.length < 1) {
			showUsage();
			return;
		}
		
		String mode = args[0];
		
		if (mode.equalsIgnoreCase("server")) {
			if (args.length < 2) {
				showUsage();
			}
			else {
				int port = Integer.parseInt(args[1]);
				
				ServerMain.start(port);
			}
		}
		else if (mode.equalsIgnoreCase("client")) {
			if (args.length < 3) {
				showUsage();
			}
			else {
				String hostname = args[1];
				
				int port = Integer.parseInt(args[2]);

				String name;
				try {
					System.out.print("Enter your name: ");
					name = IN.readLine();
				} catch (IOException e) {
					System.err.println("Invalid Name!");
					return;
				}
				
				ClientMain.start(hostname, port, name);
			}
		}
		else {
			showUsage();
		}
		
	}
	
	public static void showUsage() {
		System.out.println("Usage: <executable> [server|client] [port|host port]");
	}
	
}
