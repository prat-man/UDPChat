package com.pramanda.sockets;

import com.pramanda.sockets.client.ClientMain;
import com.pramanda.sockets.server.ServerMain;

public class Main {

	public static void main(String[] args) {
		
		if (args.length < 1) {
			showUsage();
			return;
		}
		
		String mode = args[0];
		
		if (mode.equalsIgnoreCase("server")) {
			if (args.length < 2) {
				showUsage();
			}
			else {
				int port = Integer.parseInt(args[1]);
				ServerMain.start(port);
			}
		}
		else if (mode.equalsIgnoreCase("client")) {
			if (args.length < 3) {
				showUsage();
			}
			else {
				String hostname = args[1];
				int port = Integer.parseInt(args[2]);
				ClientMain.start(hostname, port);
			}
		}
		else {
			showUsage();
		}
		
	}
	
	public static void showUsage() {
		System.out.println("Usage: <executable> [server|client] [port|host port]");
	}
	
}
