package com.pramanda.sockets.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClientMain {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));

	public static void start(String hostname, int port) {
		
		String name = null;
		
		do {
			System.out.print("Enter your name: ");
			try {
				name = IN.readLine().trim();
			} catch (IOException e) {
				System.err.println("Invalid Input!");
			}
		}
		while (name.length() == 0);
		
		Client client = new Client(hostname, port, name);
		
		client.start();
		
	}

}
