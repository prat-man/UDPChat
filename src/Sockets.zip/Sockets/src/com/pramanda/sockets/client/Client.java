package com.pramanda.sockets.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

public class Client extends Thread {
	
	public static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));
	
	private DatagramSocket socket;
	
	private String hostname;
	
	private int port;
	
	private String name;
	
	private boolean kill;
	
	public Client(String hostname, int port, String name) {
		this.hostname = hostname;
		this.port = port;
		this.name = name;
	}
	
	public void run() {
		
		try {
			socket = new DatagramSocket();
			
			socket.setSoTimeout(5000);
			
			this.connect();
			
			// start a reader thread
			Thread reader = new Thread(() -> {
				byte[] buf = new byte[1024];
				
				DatagramPacket receivedPacket = new DatagramPacket(buf, 1024);
				
			    while (!kill) {
			    	try {
			    		// try to receive a packet
					    socket.receive(receivedPacket);
					    
					    // get data from packet
					    String receivedData = new String(receivedPacket.getData(), 0, receivedPacket.getLength()).trim();
					    
					    System.err.println(receivedData);
					    
					    if (receivedData.equalsIgnoreCase("[SERVER] shutdown")) {
					    	System.err.println("\n[FATAL] Server is shutting down!\nPress [ENTER] to continue ...");
					    	kill();
					    }
					    
			    	} catch (SocketTimeoutException e1) {
						// TIMEOUT
						// DO NOTHING
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			    }
			});
			
			reader.start();
			
			
			// write user input to server
			InetAddress IPAddress = null;
			
			try {
				IPAddress = InetAddress.getByName(hostname);
			} catch (UnknownHostException e1) {
				e1.printStackTrace();
			}
			
			while (!kill) {
				String sendData = null;
				try {
					sendData = IN.readLine();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				if (sendData == null) continue;
			
				if (sendData.equalsIgnoreCase("disconnect")) {
					kill();
				}
				
				byte[] sendBuf = sendData.getBytes();
				
				DatagramPacket sendPacket = new DatagramPacket(sendBuf, sendBuf.length, IPAddress, port);
				
				try {
					socket.send(sendPacket);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			try {
				reader.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		catch (SocketException e) {
			e.printStackTrace();
		}
		finally {
			if (socket != null) socket.close();
		}
		
	}
	
	public void connect() {
		
		String data = "connect " + name;
		
		byte[] dataBuf = data.getBytes();
		
		InetAddress IPAddress = null;
		
		try {
			IPAddress = InetAddress.getByName(hostname);
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
		
		DatagramPacket packet = new DatagramPacket(dataBuf, dataBuf.length, IPAddress, port);
		
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void kill() {
		this.kill = true;
	}
	
}
